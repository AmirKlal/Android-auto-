package com.example.autologin

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private val emailList = listOf(
        "example1@mail.com",
        "example2@mail.com",
        "example3@mail.com"
    )
    private val password = "Amir@123"
    private var currentIndex = 0
    private var loginAttempts = 0

    private fun loadEmailLogin() {
        val currentEmail = emailList[currentIndex]
        emailTextView.text = "Logging in as: $currentEmail\nPassword: $password"
        webView.loadUrl("https://www.paypal.com/signin?locale.x=en_GB")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()

        loadEmailLogin()

        reloginButton.setOnClickListener {
            if (loginAttempts < 3) {
                loginAttempts++
                loadEmailLogin()
                Toast.makeText(this, "Relogin $loginAttempts/3", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Max 3 logins allowed for this email", Toast.LENGTH_SHORT).show()
            }
        }

        nextButton.setOnClickListener {
            currentIndex++
            loginAttempts = 0
            if (currentIndex < emailList.size) {
                loadEmailLogin()
            } else {
                Toast.makeText(this, "All emails completed", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }
}
